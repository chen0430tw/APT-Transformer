#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MVP CLI shim:
  python -m apt.cli.commands.import_apx path/to/demo.apx
"""
from __future__ import annotations
import argparse
from apt.__main__ import _cmd_import

def main(argv=None):
    p = argparse.ArgumentParser(prog="apt import", description="Import APX package")
    p.add_argument("apx_path", help="path to .apx")
    args = p.parse_args(argv)
    _cmd_import(args.apx_path)

if __name__ == "__main__":
    main()
