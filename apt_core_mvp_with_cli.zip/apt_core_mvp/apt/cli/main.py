#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convenience wrapper:
    python -m apt.cli.main import path/to/demo.apx
is equivalent to:
    python -m apt import path/to/demo.apx
"""
from __future__ import annotations
from apt.__main__ import main

if __name__ == "__main__":
    main()
