#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APT CLI (MVP)
Usage:
    python -m apt import path/to/demo.apx
"""
from __future__ import annotations
import argparse, json, os
from apt.core.apx import install_apx, parse_apx, APX_REG_DIR

def _cmd_import(apx_path: str):
    out_dir = install_apx(apx_path)
    meta = parse_apx(apx_path)
    reg_path = os.path.join(APX_REG_DIR, "registry.json")
    with open(reg_path, "r", encoding="utf-8") as f:
        registry = json.load(f)
    info = {
        "name": meta.name,
        "version": meta.version,
        "installed_to": out_dir,
        "registry_entry": registry.get(f"{meta.name}@{meta.version}", {})
    }
    print(json.dumps(info, indent=2, ensure_ascii=False))

def main(argv=None):
    parser = argparse.ArgumentParser(prog="apt", description="APT CLI (MVP)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_import = sub.add_parser("import", help="Import an APX package")
    p_import.add_argument("apx_path", help="path to .apx")

    args = parser.parse_args(argv)

    if args.cmd == "import":
        _cmd_import(args.apx_path)
    else:
        parser.error(f"unknown command: {args.cmd!r}")

if __name__ == "__main__":
    main()
