# -*- coding: utf-8 -*-
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional, Literal

Role = Literal["writer","observer"]
Phase = Literal["train","eval","infer"]
Decision = Literal["pass","block","rewrite"]

@dataclass
class HookContext:
    phase: Phase
    step: int
    batch_size: int
    device: str
    meta: Dict[str, Any] = None

@dataclass
class HookResult:
    ok: bool = True
    role: Role = "observer"
    metrics: Dict[str, float] = None
    decision: Decision = "pass"
    payload: Optional[Any] = None
    note: str = ""
    time_ms: float = 0.0

class SafetyHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def pre_forward(self, ctx: HookContext, batch) -> HookResult: return HookResult()
    def post_forward(self, ctx: HookContext, logits, batch) -> HookResult: return HookResult()

class RewardHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def compute(self, ctx: HookContext, batch, outputs) -> HookResult: return HookResult()

class RouterHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def suggest(self, ctx: HookContext, hidden_states) -> HookResult: return HookResult()

class LossShapingHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def extra_loss(self, ctx: HookContext, batch, outputs) -> HookResult:
        return HookResult(metrics={}, payload={"loss":0.0,"weight":0.0,"cap":0.0})

class OptimizerHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def step(self, ctx: HookContext, model, opt, batch) -> HookResult: return HookResult()

class RetrievalHook:
    def policy(self) -> Dict[str, Any]: return {"role":"observer","version":"v1","caps":[]}
    def retrieve_async(self, ctx: HookContext, query) -> HookResult: return HookResult()
    def poll(self, ctx: HookContext, task_id) -> HookResult: return HookResult()
