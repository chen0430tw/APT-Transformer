# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import Dict, Any

class Decision:
    def __init__(self):
        self.table: Dict[str, Dict[str, any]] = {}

def _choose_by(pref: str, slot: str, plugins: Dict[str, Any]):
    if pref == "builtin":
        return {"writer": f"builtin.{slot}", "observers": sorted(list(plugins.keys()))}
    if pref == "plugin":
        if plugins:
            first = sorted(plugins.keys())[0]
            observers = [f"builtin.{slot}"] + [k for k in plugins.keys() if k != first]
            return {"writer": first, "observers": observers}
        return {"writer": f"builtin.{slot}", "observers": []}
    return None

def negotiate(apx_prefers: str = "builtin", user_priority: Dict[str,str] = None, plugins: Dict[str,Any] = None) -> Decision:
    user_priority = user_priority or {}
    plugins = plugins or {}
    slots = ["safety","reward","router","loss_shaping","optimizer"]
    decided = Decision()
    for slot in slots:
        pref = user_priority.get(slot, apx_prefers)
        decided.table[slot] = _choose_by(pref, slot, plugins) or {"writer": f"builtin.{slot}","observers": sorted(list(plugins.keys()))}
    return decided
