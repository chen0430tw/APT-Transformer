# -*- coding: utf-8 -*-
from __future__ import annotations
"""
APX parser/installer (MVP)
- 解析 apx.yaml（最小 YAML 子集）
- 安装到 ~/.apt/models/<name>@<version>
"""
import os, json, zipfile, time
from dataclasses import dataclass
from typing import Dict, Any

APX_REG_DIR = os.path.expanduser("~/.apt/models")
os.makedirs(APX_REG_DIR, exist_ok=True)

class ApxError(Exception):
    pass

@dataclass
class ApxMeta:
    name: str
    version: str
    apx_version: int
    type: str
    entry_model: str
    entry_tokenizer: str
    artifacts: Dict[str, str]

def _read_yaml_text(zf: zipfile.ZipFile, path: str) -> str:
    try:
        with zf.open(path, "r") as f:
            return f.read().decode("utf-8")
    except KeyError:
        raise ApxError(f"Missing required file in APX: {path}")

def _parse_min_yaml(text: str) -> Dict[str, Any]:
    # 极简 YAML（key: scalar），仅用于 MVP；生产建议改为 PyYAML
    data = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line and not line.startswith((" ", "\t")):
            k, v = line.split(":", 1)
            data[k.strip()] = v.strip().strip('"\'' )
    return data

def _find_block(raw: str, prefix: str) -> Dict[str, str]:
    start = raw.find(prefix + ":")
    if start < 0:
        return {}
    block = {}
    for ln in raw[start:].splitlines()[1:]:
        if not ln.startswith("  "):
            break
        ln = ln.strip()
        if ":" in ln:
            k, v = ln.split(":", 1)
            block[k.strip()] = v.strip().strip('"\'' )
    return block

def parse_apx(apx_path: str) -> ApxMeta:
    if not zipfile.is_zipfile(apx_path):
        raise ApxError("APX must be a ZIP container")
    with zipfile.ZipFile(apx_path, "r") as zf:
        raw = _read_yaml_text(zf, "apx.yaml")
        meta = _parse_min_yaml(raw)
        for k in ("apx_version","name","version","type"):
            if k not in meta:
                raise ApxError(f"apx.yaml missing field: {k}")
        if meta["type"] != "model":
            raise ApxError("APX type must be 'model'")
        ep = _find_block(raw, "entrypoints")
        art = _find_block(raw, "artifacts")
        if "model_adapter" not in ep or "tokenizer_adapter" not in ep:
            raise ApxError("entrypoints.model_adapter/tokenizer_adapter are required")
        for k in ("config","weights","tokenizer"):
            if k not in art:
                raise ApxError(f"artifacts.{k} is required")
        return ApxMeta(
            name=meta["name"],
            version=meta["version"],
            apx_version=int(meta["apx_version"]),
            type=meta["type"],
            entry_model=ep["model_adapter"],
            entry_tokenizer=ep["tokenizer_adapter"],
            artifacts=art,
        )

def install_apx(apx_path: str) -> str:
    meta = parse_apx(apx_path)
    out_dir = os.path.join(APX_REG_DIR, f"{meta.name}@{meta.version}")
    os.makedirs(out_dir, exist_ok=True)
    allow = ("apx.yaml","model/","artifacts/","mapping/","tests/","META-INF/","logs/")
    with zipfile.ZipFile(apx_path, "r") as zf:
        for m in zf.infolist():
            if any(m.filename.startswith(p) for p in allow):
                zf.extract(m, out_dir)
    reg = os.path.join(APX_REG_DIR, "registry.json")
    registry = {}
    if os.path.exists(reg):
        registry = json.load(open(reg,"r",encoding="utf-8"))
    registry[f"{meta.name}@{meta.version}"] = {"path": out_dir, "time": time.time()}
    json.dump(registry, open(reg,"w",encoding="utf-8"), indent=2, ensure_ascii=False)
    return out_dir
