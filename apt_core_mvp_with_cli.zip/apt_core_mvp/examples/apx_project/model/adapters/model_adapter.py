# minimal demo adapter
class DemoAdapter:
    def __init__(self):
        pass
    @classmethod
    def build(cls, config: dict):
        return cls()
    @classmethod
    def from_pretrained(cls, path: str):
        return cls()
    def forward(self, batch):
        return {'logits': None}
    def loss_fn(self, logits, batch):
        return 0.0
    def generate(self, inputs, **kw):
        return [0]
    def save_pretrained(self, out_dir: str):
        pass
