class DemoTokAdapter:
    @classmethod
    def from_files(cls, dir):
        return cls()
    def encode(self, texts, max_len=128):
        return {'input_ids': [[0]]}
    def decode(self, ids):
        return ''
