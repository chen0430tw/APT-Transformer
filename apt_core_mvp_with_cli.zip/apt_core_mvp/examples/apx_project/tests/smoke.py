print("smoke ok")
