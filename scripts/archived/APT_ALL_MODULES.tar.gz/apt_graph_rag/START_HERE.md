# 🚀 START HERE - APT GraphRAG 快速入门

<div align="center">

**欢迎使用 APT GraphRAG!**

下一代知识图谱系统 - 基于泛图分析的革命性框架

[5分钟快速开始](#5分钟快速开始) • [文件说明](#文件说明) • [使用场景](#使用场景) • [常见问题](#常见问题)

</div>

---

## 📦 你获得了什么?

一个完整的、生产就绪的 GraphRAG 系统，包含:

✅ **4个核心模块** (~3900行代码)
- 泛图数据结构
- Hodge-Laplacian谱分析
- 图脑动力学引擎
- GraphRAG统一管理器

✅ **完整文档**
- README.md - 项目主文档
- INTEGRATION.md - APT集成指南
- PROJECT_STRUCTURE.md - 架构说明

✅ **可运行示例**
- demo_full.py - 完整功能演示
- __init__.py - 快速开始示例

---

## 📁 文件说明

| 文件 | 大小 | 说明 | 优先级 |
|------|------|------|--------|
| **START_HERE.md** | - | 本文件 - 快速入门 | ⭐⭐⭐ |
| **README.md** | 8.5K | 项目主文档，理论与使用 | ⭐⭐⭐ |
| **demo_full.py** | 8.7K | 完整功能演示脚本 | ⭐⭐⭐ |
| **INTEGRATION.md** | 17K | APT项目集成详细指南 | ⭐⭐ |
| **PROJECT_STRUCTURE.md** | 7.4K | 项目结构和架构说明 | ⭐⭐ |
| **generalized_graph.py** | 16K | 泛图核心实现 | ⭐ |
| **hodge_laplacian.py** | 16K | 谱分析实现 | ⭐ |
| **graph_brain.py** | 18K | 图脑动力学实现 | ⭐ |
| **graph_rag_manager.py** | 18K | GraphRAG管理器实现 | ⭐ |
| **__init__.py** | 3.2K | 包初始化和快速示例 | ⭐ |

---

## 🎯 5分钟快速开始

### 步骤1: 查看演示 (1分钟)

```bash
# 运行快速示例
python __init__.py
```

你将看到一个简单的知识图谱构建和查询过程。

### 步骤2: 完整演示 (3分钟)

```bash
# 运行完整功能演示
python demo_full.py
```

这将展示:
- ✓ 泛图构建
- ✓ Hodge-Laplacian谱分析
- ✓ 图脑动力学演化
- ✓ 多模式查询
- ✓ 高级特性

### 步骤3: 第一个程序 (1分钟)

创建 `my_first_rag.py`:

```python
from apt_graph_rag import GraphRAGManager

# 创建系统
rag = GraphRAGManager(max_dimension=2)

# 添加知识
rag.add_triple("Python", "是", "编程语言")
rag.add_triple("Python", "用于", "AI开发")

# 构建索引
rag.build_indices()

# 查询
results = rag.query("Python AI", mode="hybrid", top_k=3)

for res in results:
    print(f"{res['entity']}: {res['score']:.4f}")
```

运行:
```bash
python my_first_rag.py
```

---

## 🎓 学习路径

### 路径1: 快速应用者 (推荐初学者)

1. ✅ 阅读本文件 (你正在做)
2. ⏭️ 运行 `demo_full.py`
3. ⏭️ 阅读 `README.md` 的"快速开始"部分
4. ⏭️ 修改 `my_first_rag.py` 使用自己的数据
5. ⏭️ 需要集成到APT? 查看 `INTEGRATION.md`

### 路径2: 深入理解者 (推荐进阶)

1. ⏭️ 阅读 `README.md` - 了解理论基础
2. ⏭️ 阅读 `PROJECT_STRUCTURE.md` - 理解架构
3. ⏭️ 阅读源码 `generalized_graph.py`
4. ⏭️ 阅读源码 `hodge_laplacian.py`
5. ⏭️ 阅读源码 `graph_brain.py`

### 路径3: 集成开发者 (推荐工程师)

1. ⏭️ 快速浏览 `README.md`
2. ⏭️ 仔细阅读 `INTEGRATION.md`
3. ⏭️ 查看集成示例代码
4. ⏭️ 复制模块到APT项目
5. ⏭️ 运行测试，逐步集成

---

## 💡 使用场景

### 场景1: 知识问答系统

```python
# 构建医疗知识图谱
rag.add_triple("感冒", "症状", "发烧")
rag.add_triple("感冒", "症状", "咳嗽")
rag.add_triple("感冒", "治疗", "多喝水")

rag.build_indices()

# 查询
results = rag.query("感冒 发烧", mode="hybrid")
# 结果: 相关的症状、治疗方法
```

### 场景2: 科研论文关联

```python
# 论文-作者-机构-主题关系
rag.add_triple("论文A", "作者", "张三")
rag.add_triple("张三", "单位", "清华大学")
rag.add_triple("论文A", "主题", "深度学习")

# 多跳推理
results = rag.query("深度学习 清华", mode="spectral")
```

### 场景3: 产品推荐

```python
# 用户-产品-属性关系
rag.add_triple("用户A", "喜欢", "科幻电影")
rag.add_triple("电影X", "类型", "科幻")
rag.add_triple("电影X", "导演", "诺兰")

# 图脑动力学推荐
results = rag.query("用户A 电影", mode="brain")
```

---

## 🔧 核心特性一览

### 1. 泛图 (超越传统图谱)

```python
# 不只是 (A)-[rel]->(B)
# 而是支持任意 p 元关系

gg = GeneralizedGraph(max_dimension=2)

# 0-细胞: 实体
gg.add_cell(0, "实体A")

# 1-细胞: 二元关系
gg.add_cell(1, "关系1", boundary={"实体A", "实体B"})

# 2-细胞: 三元关系/事实
gg.add_cell(2, "事实1", boundary={"关系1", "关系2"})
```

### 2. 谱分析 (拓扑诊断)

```python
hodge = HodgeLaplacian(gg)

# Betti数: 检测知识孔洞
betti = hodge.compute_betti_numbers()
print(f"连通分支: {betti[0]}")
print(f"循环(悖论): {betti[1]}")
print(f"空洞(缺失): {betti[2]}")

# 谱特征: 稳定性分析
eigenvalues, _ = hodge.compute_spectrum(0)
```

### 3. 图脑 (动态演化)

```python
brain = GraphBrainEngine(gg, T_cog=1.0)

# 激活特定节点
brain.activate_cells(0, [0, 1], strength=2.0)

# 观察传播
for _ in range(100):
    brain.evolve_step(dt=0.1)

# 获取最激活的概念
top_concepts = brain.get_activated_cells(0, top_k=10)
```

### 4. 多模式查询

```python
# 谱推理: 全局拓扑引导
results_spectral = rag.query(query, mode="spectral")

# 图脑: 局部激活传播
results_brain = rag.query(query, mode="brain")

# 混合: 最优组合
results_hybrid = rag.query(query, mode="hybrid")
```

---

## ❓ 常见问题

### Q1: 如何集成到APT项目?

**A**: 查看 `INTEGRATION.md`，有完整的集成指南，包括:
- 文件复制方法
- 代码修改示例
- 命令行参数扩展
- 训练流程集成

### Q2: 性能如何? 能处理多大规模?

**A**: 性能基准参考:
- 小规模 (~100实体): <1秒构建
- 中规模 (~1K实体): ~5秒构建
- 大规模 (~10K实体): ~30秒构建
- 超大规模 (~100K实体): ~5分钟构建

查询通常在 <1秒 内完成。

### Q3: 需要什么依赖?

**A**: 核心依赖只需要:
```bash
pip install numpy scipy
```

可选依赖:
```bash
pip install matplotlib networkx  # 可视化和参考
```

### Q4: 如何调试?

**A**: 启用详细日志:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Q5: 与传统知识图谱的区别?

**A**: 主要优势:
- ✅ 支持高阶关系 (p元)
- ✅ 拓扑诊断 (Betti数)
- ✅ 动态演化 (图脑)
- ✅ 谱推理 (Laplacian)
- ✅ 自动相变 (CPHL)

### Q6: 如何优化性能?

**A**: 优化建议:
1. 批量添加: `add_triples_batch()`
2. 降低维度: `max_dimension=1`
3. 禁用未用组件: `enable_brain=False`
4. 减少谱计算: `k=10` 而非默认20

---

## 🎉 下一步行动

现在你已经了解了基本情况，选择一条路径开始:

### 🟢 我想快速试用
→ 运行 `demo_full.py`
→ 修改 `my_first_rag.py`

### 🔵 我想深入学习
→ 阅读 `README.md`
→ 阅读 `PROJECT_STRUCTURE.md`
→ 研究源码

### 🟠 我想集成到APT
→ 阅读 `INTEGRATION.md`
→ 复制模块到APT
→ 运行测试

### 🔴 我遇到问题
→ 查看 `INTEGRATION.md` 的"故障排除"
→ 检查依赖是否安装
→ 启用DEBUG日志

---

## 📞 需要帮助?

1. 📖 查看文档 - `README.md`, `INTEGRATION.md`
2. 🔍 搜索源码 - 所有函数都有详细注释
3. 🧪 运行测试 - 各模块可独立测试
4. 💬 提Issue - GitHub Issues

---

## 🌟 核心价值主张

### 为什么选择 APT GraphRAG?

**传统知识图谱**:
- ❌ 只支持二元关系
- ❌ 静态结构
- ❌ 路径枚举推理
- ❌ 无拓扑诊断

**APT GraphRAG**:
- ✅ 支持任意p元关系
- ✅ 动态演化 (图脑)
- ✅ 谱推理 (Laplacian)
- ✅ 拓扑诊断 (Betti数)
- ✅ 自动相变 (CPHL)

### 理论基础

- 📐 **泛图分析** (GGA) - 统一高维结构
- 🎵 **Hodge-Laplacian** - 谱理论与拓扑
- 🧠 **图脑动力学** - 认知演化模拟
- ⚛️ **统计物理** - 自由能最小化

---

## 📚 推荐阅读顺序

1. ✅ **START_HERE.md** (本文件) - 5分钟
2. ⏭️ **demo_full.py** (运行) - 3分钟
3. ⏭️ **README.md** (快速开始部分) - 10分钟
4. ⏭️ **自己写个小程序** - 20分钟
5. ⏭️ **README.md** (完整阅读) - 30分钟
6. ⏭️ **PROJECT_STRUCTURE.md** - 20分钟
7. ⏭️ **INTEGRATION.md** (如需集成) - 40分钟
8. ⏭️ **源码学习** - 按需

---

<div align="center">

**准备好了吗? 开始你的 GraphRAG 之旅! 🚀**

```bash
python demo_full.py
```

**Made with ❤️ by chen0430tw**

[GitHub](https://github.com/chen0430tw/APT-Transformer) • [文档](README.md) • [集成指南](INTEGRATION.md)

</div>
