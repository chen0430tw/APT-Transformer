# APT GraphRAG - 项目结构说明

## 📁 完整文件清单

```
apt_graph_rag/
├── __init__.py                    # 包初始化，导出核心类
├── README.md                      # 项目主文档
├── INTEGRATION.md                 # APT集成指南  
├── PROJECT_STRUCTURE.md           # 本文件 - 结构说明
│
├── generalized_graph.py           # 泛图核心 (1200+ 行)
│   ├── Cell                       # 细胞类
│   └── GeneralizedGraph           # 泛图主类
│       ├── 基础操作 (添加/删除/查询)
│       ├── 拓扑查询 (边界/邻居/度数)
│       ├── 链复形验证
│       ├── 关联矩阵计算
│       └── 持久化 (保存/加载)
│
├── hodge_laplacian.py             # Hodge-Laplacian谱分析 (600+ 行)
│   └── HodgeLaplacian
│       ├── 外微分/余微分算子
│       ├── Laplacian计算
│       ├── 谱分解
│       ├── Betti数计算
│       ├── 欧拉示性数
│       └── Hodge分解
│
├── graph_brain.py                 # 图脑动力学引擎 (800+ 行)
│   ├── GraphBrainState            # 状态快照类
│   └── GraphBrainEngine
│       ├── 自由能计算
│       ├── 动力学演化
│       ├── 拓扑相变 (CPHL)
│       ├── 激活传播
│       └── 统计与报告
│
├── graph_rag_manager.py           # GraphRAG管理器 (700+ 行)
│   └── GraphRAGManager
│       ├── 知识添加 (三元组)
│       ├── 索引构建
│       ├── 多模式查询
│       ├── 统计与可视化
│       └── 持久化
│
└── demo_full.py                   # 完整功能演示 (400+ 行)
    ├── 第一部分: 泛图基础
    ├── 第二部分: Hodge-Laplacian
    ├── 第三部分: 图脑动力学
    ├── 第四部分: GraphRAG系统
    └── 第五部分: 高级特性
```

## 📊 代码规模统计

| 模块 | 行数 | 功能数 | 核心类 |
|------|------|--------|--------|
| generalized_graph.py | ~1200 | 30+ | 2 |
| hodge_laplacian.py | ~600 | 15+ | 1 |
| graph_brain.py | ~800 | 20+ | 2 |
| graph_rag_manager.py | ~700 | 15+ | 1 |
| 其他文件 | ~600 | - | - |
| **总计** | **~3900** | **80+** | **6** |

## 🔍 模块依赖关系

```
GraphRAGManager (最上层)
    ├── GeneralizedGraph (数据结构)
    ├── HodgeLaplacian (谱分析)
    │   └── GeneralizedGraph
    └── GraphBrainEngine (动力学)
        └── GeneralizedGraph
        └── HodgeLaplacian
```

## 🎯 核心类详解

### 1. GeneralizedGraph (泛图)

**职责**: 统一的高维图数据结构

**关键方法**:
- `add_cell(dim, id, boundary)` - 添加p-细胞
- `compute_incidence_matrix(p)` - 计算关联矩阵B_p
- `get_boundary(dim, id)` - 获取边界
- `get_neighbors(dim, id)` - 获取邻居
- `from_edge_list(edges)` - 从边列表构建
- `from_knowledge_triples(triples)` - 从三元组构建

**数学实现**:
- 链复形条件: ∂_{p-1} ∘ ∂_p = ∅
- 关联矩阵: B_p[i,j] = 边界关系

---

### 2. HodgeLaplacian (谱分析)

**职责**: 计算拓扑和谱特征

**关键方法**:
- `compute_laplacian(p)` - 计算L_p = d_{p-1}δ_{p-1} + δ_p d_p
- `compute_spectrum(p, k)` - 谱分解
- `compute_betti_numbers()` - 计算拓扑不变量
- `hodge_decomposition(p, signal)` - Hodge分解

**数学实现**:
- 外微分: d_p = B_{p+1}^T
- 余微分: δ_p = B_p
- Betti数: β_p = dim(ker L_p)

---

### 3. GraphBrainEngine (图脑)

**职责**: 动态认知演化模拟

**关键方法**:
- `evolve_step(dt, drive)` - 时间步演化
- `activate_cells(dim, indices, strength)` - 激活节点
- `get_activated_cells(dim, top_k)` - 获取最激活的
- `_compute_free_energy(P, W)` - 计算F = U - T·S
- `_trigger_phase_transition()` - 触发CPHL

**数学实现**:
- 自由能: F = Σw_e·Φ(e,P) - T·(-Σw_e log w_e)
- 演化: dP/dt = -∇F + 扩散 + 驱动
- Hebb学习: dW/dt = η·P_i·P_j

---

### 4. GraphRAGManager (统一接口)

**职责**: 知识图谱管理和查询

**关键方法**:
- `add_triple(s, p, o)` - 添加知识三元组
- `build_indices()` - 构建所有索引
- `query(text, mode, top_k)` - 多模式查询
- `get_statistics()` - 获取统计信息
- `save(dir)` / `load(dir)` - 持久化

**查询模式**:
- `spectral`: 谱推理 (Laplacian引导)
- `brain`: 图脑动力学 (激活传播)
- `hybrid`: 混合模式 (加权组合)

---

## 🛠️ 技术栈

### 核心依赖

```python
numpy>=1.20.0        # 数值计算
scipy>=1.7.0         # 稀疏矩阵、特征值求解
```

### 可选依赖

```python
matplotlib>=3.3.0    # 可视化 (未来)
networkx>=2.6        # 图算法 (参考)
torch>=1.10.0        # GPU加速 (未来)
```

---

## 📚 使用流程

### 基础流程

```python
from apt_graph_rag import GraphRAGManager

# 1. 创建
rag = GraphRAGManager(max_dimension=2)

# 2. 添加知识
rag.add_triple("实体1", "关系", "实体2")

# 3. 构建索引
rag.build_indices()

# 4. 查询
results = rag.query("查询文本")
```

### 高级流程

```python
# 直接操作泛图
gg = rag.gg
cell = gg.get_cell(0, "entity:实体1")

# 直接操作谱
hodge = rag.hodge
eigenvalues, _ = hodge.compute_spectrum(0)

# 直接操作图脑
brain = rag.brain
brain.activate_cells(0, [0, 1], strength=2.0)
brain.evolve_step(dt=0.1)
```

---

## 🔬 测试与验证

### 单元测试

```bash
# 测试各模块
python generalized_graph.py
python hodge_laplacian.py
python graph_brain.py
python graph_rag_manager.py
```

### 集成测试

```bash
# 快速开始示例
python __init__.py

# 完整演示
python demo_full.py
```

### 性能基准

| 规模 | 实体数 | 关系数 | 构建时间 | 查询时间 |
|------|--------|--------|----------|----------|
| 小 | ~100 | ~200 | <1s | <0.1s |
| 中 | ~1K | ~2K | ~5s | <0.5s |
| 大 | ~10K | ~20K | ~30s | ~1s |
| 超大 | ~100K | ~200K | ~5min | ~5s |

---

## 🎓 学习路径

### 初学者

1. 阅读 `README.md` - 了解基本概念
2. 运行 `demo_full.py` - 看完整示例
3. 阅读 `INTEGRATION.md` - 学习集成

### 进阶

1. 阅读 `generalized_graph.py` - 理解数据结构
2. 阅读 `hodge_laplacian.py` - 理解谱理论
3. 阅读 `graph_brain.py` - 理解动力学

### 专家

1. 研究数学推导 - 泛图分析论文
2. 优化性能 - GPU加速、稀疏优化
3. 扩展功能 - 新算法、新应用

---

## 🌟 核心创新点

1. **泛图统一框架**
   - 支持任意p元关系
   - 链复形保证拓扑一致性
   - 可扩展到高维结构

2. **Hodge-Laplacian谱理论**
   - Betti数检测拓扑孔洞
   - 谱间隙衡量稳定性
   - Hodge分解揭示内在结构

3. **图脑动力学**
   - 自由能驱动演化
   - 自动相变重组 (CPHL)
   - Hebb学习自组织

4. **统一查询框架**
   - 谱推理 (全局拓扑)
   - 激活传播 (局部动力学)
   - 混合模式 (最优组合)

---

## 📖 相关资源

### 项目文档
- [README.md](README.md) - 项目主文档
- [INTEGRATION.md](INTEGRATION.md) - APT集成指南
- 源码注释 - 详细实现说明

### 理论基础
- 泛图分析 (GGA) 论文
- Hodge-Laplacian谱理论
- 非平衡态统计物理

### 开发资源
- NumPy文档
- SciPy稀疏矩阵
- NetworkX参考

---

**版本**: v0.1.0  
**作者**: chen0430tw  
**日期**: 2024-12  
**许可**: MIT  
