# APT模型管理员模式使用指南

## 📋 目录

1. [简介](#简介)
2. [安装](#安装)
3. [快速开始](#快速开始)
4. [命令参考](#命令参考)
5. [使用场景](#使用场景)
6. [常见问题](#常见问题)
7. [安全注意事项](#安全注意事项)

---

## 简介

APT模型管理员模式是一个强大的调试和研究工具，允许开发者：

- 🔓 **绕过安全层**：用于测试模型的原始能力
- 🐛 **高级调试**：查看模型内部状态和生成过程
- ⚙️ **实时参数调整**：动态修改生成参数
- 📊 **性能分析**：基准测试和统计信息
- 🎯 **自定义行为**：通过系统提示引导模型

⚠️ **重要**: 此工具仅供研究和开发使用，不应在生产环境中使用。

---

## 安装

### 方法1：作为APT项目的一部分

1. 将文件放置在正确位置：
   ```
   apt_model/
   ├── interactive/
   │   ├── __init__.py
   │   ├── admin_mode.py      ← 管理员模式主文件
   │   └── chat.py
   └── ...
   ```

2. 安装APT包：
   ```bash
   cd apt_model
   pip install -e .
   ```

### 方法2：独立使用

1. 确保以下文件在同一目录：
   - `admin_mode.py`
   - `start_admin_mode.py`

2. 安装依赖：
   ```bash
   pip install torch transformers
   ```

---

## 快速开始

### 基本启动

```bash
# 使用默认设置
python start_admin_mode.py

# 或直接运行
python admin_mode.py
```

### 带参数启动

```bash
# 指定模型路径和自定义密码
python start_admin_mode.py --model-path /path/to/model --password mypassword

# 使用中文分词器
python start_admin_mode.py --tokenizer-type chinese-char

# 强制使用CPU
python start_admin_mode.py --force-cpu
```

### 登录和使用

```
你: /login aptadmin
✅ 管理员身份验证成功!

你: /safety off
⚠️ 警告: 安全层已禁用

你: /system 你是一个友好的AI助手
✅ 系统提示已更改

你: 你好，介绍一下你自己
APT模型: 你好！我是...
```

---

## 命令参考

### 基本命令（无需认证）

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/login` | `<密码>` | 管理员身份验证 | `/login aptadmin` |
| `/help` | - | 显示帮助信息 | `/help` |
| `/exit` | - | 退出程序 | `/exit` |
| `/clear` | - | 清除对话历史 | `/clear` |

### 参数调整命令（无需认证）

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/temp` | `<值>` | 设置温度 (0.0-2.0) | `/temp 0.8` |
| `/top_p` | `<值>` | 设置top-p (0.0-1.0) | `/top_p 0.95` |
| `/length` | `<值>` | 设置最大生成长度 | `/length 200` |

### 管理员命令（需要认证）

#### 安全与调试

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/admin` | - | 显示管理员帮助 | `/admin` |
| `/safety` | `on/off` | 控制安全层 | `/safety off` |
| `/debug` | `on/off` | 启用高级调试 | `/debug on` |
| `/raw` | `on/off` | 原始输出模式 | `/raw on` |
| `/probs` | `on/off` | 显示词元概率 | `/probs on` |

#### 系统提示

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/system` | `<提示>` | 设置系统提示 | `/system 你是一个数学老师` |
| `/reset_system` | - | 重置系统提示 | `/reset_system` |

#### 模型分析

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/inspect` | - | 检查模型信息 | `/inspect` |
| `/benchmark` | - | 性能基准测试 | `/benchmark` |
| `/stats` | - | 显示统计信息 | `/stats` |
| `/visualize` | - | 可视化注意力层 | `/visualize` |

#### 高级操作

| 命令 | 参数 | 说明 | 示例 |
|------|------|------|------|
| `/export` | `<文件>` | 导出会话 | `/export session.json` |
| `/override` | `<json>` | 覆盖参数 | `/override {"temp":0.9}` |

---

## 使用场景

### 场景1：测试模型原始能力

```bash
# 启动管理员模式
python start_admin_mode.py

# 登录
/login aptadmin

# 禁用安全层
/safety off

# 测试模型
你: [测试问题]
```

**用途**: 了解模型在没有安全限制时的表现

### 场景2：调整对话风格

```bash
# 设置系统提示
/system 你是一个幽默风趣的AI助手，喜欢用表情符号

# 调整温度以增加创造性
/temp 0.9

# 开始对话
你: 给我讲个笑话
```

**用途**: 研究不同系统提示对模型输出的影响

### 场景3：性能调优

```bash
# 运行基准测试
/benchmark

# 查看统计信息
/stats

# 调整参数
/temp 0.7
/length 50

# 再次测试
/benchmark
```

**用途**: 找到最佳的性能参数配置

### 场景4：调试模型行为

```bash
# 启用高级调试
/debug on

# 显示词元概率
/probs on

# 检查模型信息
/inspect

# 生成响应并查看详细信息
你: 测试输入
```

**用途**: 深入理解模型的生成过程

### 场景5：导出研究数据

```bash
# 进行多轮对话...

# 导出整个会话
/export research_session_001.json

# 数据包含:
# - 所有对话历史
# - 使用的参数
# - 统计信息
```

**用途**: 保存实验数据供后续分析

---

## 常见问题

### Q1: 忘记管理员密码怎么办？

**方法1**: 修改代码中的默认密码
```python
# 在 admin_mode.py 中找到:
admin_password: str = "aptadmin"
# 改为:
admin_password: str = "newpassword"
```

**方法2**: 通过命令行指定新密码
```bash
python start_admin_mode.py --password newpassword
```

**方法3**: 直接修改认证状态（仅开发环境）
```python
from apt_model.interactive.admin_mode import APTAdminMode

admin = APTAdminMode()
admin.authenticated = True  # 跳过密码验证
admin.start()
```

### Q2: 模型加载失败怎么办？

**检查清单**:
1. ✅ 确认模型路径正确
2. ✅ 确认有足够的内存/显存
3. ✅ 尝试使用 `--force-cpu` 参数
4. ✅ 检查PyTorch是否正确安装

**解决方案**:
```bash
# 使用CPU模式
python start_admin_mode.py --force-cpu

# 检查PyTorch
python -c "import torch; print(torch.__version__)"
```

### Q3: 如何在没有GPU的情况下使用？

```bash
python start_admin_mode.py --force-cpu
```

### Q4: 命令不起作用？

确保命令以 `/` 开头：
```
正确: /help
错误: help
```

### Q5: 如何保存对话记录？

```bash
# 方法1: 使用导出命令
/export my_session.json

# 方法2: 重定向输出
python start_admin_mode.py > session.log 2>&1
```

### Q6: 安全层禁用后有什么风险？

**风险**:
- ❌ 可能生成不当内容
- ❌ 绕过内容过滤
- ❌ 不适合公开演示

**建议**:
- ✅ 仅在研究环境使用
- ✅ 不要在生产环境禁用
- ✅ 妥善保管测试数据

### Q7: 如何提高生成质量？

**调整参数**:
```bash
# 更保守的生成
/temp 0.5
/top_p 0.85

# 更创造性的生成
/temp 0.9
/top_p 0.95

# 更长的响应
/length 200
```

---

## 安全注意事项

### ⚠️ 重要警告

1. **禁用安全层的后果**
   - 模型可能生成有害、偏见或不当内容
   - 仅用于研究和理解模型能力
   - 不要在面向用户的应用中使用

2. **密码保护**
   - 默认密码 `aptadmin` 仅供开发使用
   - 生产环境必须使用强密码
   - 定期更改密码

3. **数据隐私**
   - 导出的会话可能包含敏感信息
   - 妥善保管所有导出文件
   - 不要分享包含隐私数据的会话

4. **使用环境**
   - ✅ 研究和开发环境
   - ✅ 模型测试和调试
   - ✅ 学术研究
   - ❌ 生产环境
   - ❌ 面向用户的服务
   - ❌ 公开演示

### 推荐实践

1. **使用隔离环境**
   ```bash
   # 创建虚拟环境
   python -m venv admin_env
   source admin_env/bin/activate  # Linux/Mac
   # 或
   admin_env\Scripts\activate  # Windows
   ```

2. **限制访问权限**
   ```bash
   # 设置文件权限（Linux/Mac）
   chmod 700 admin_mode.py
   chmod 700 start_admin_mode.py
   ```

3. **使用强密码**
   ```bash
   # 启动时指定强密码
   python start_admin_mode.py --password "$(openssl rand -base64 32)"
   ```

4. **记录所有操作**
   ```bash
   # 启用详细日志
   python start_admin_mode.py --verbose > admin.log 2>&1
   ```

---

## 技术细节

### 架构设计

```
┌─────────────────────────────────────┐
│     APT Admin Mode Interface        │
├─────────────────────────────────────┤
│  Authentication Layer               │
│  Command Processor                  │
│  Parameter Controller               │
├─────────────────────────────────────┤
│     APT Model Core                  │
│  - Text Generation                  │
│  - Safety Layer (可选)             │
│  - Token Processing                 │
└─────────────────────────────────────┘
```

### 关键功能实现

**1. 安全层绕过**
```python
if self.safety_layer_enabled:
    response = self._apply_safety_filter(response)
else:
    # 直接返回原始输出
    pass
```

**2. 实时参数调整**
```python
def generate_response(self, prompt):
    outputs = self.model.generate(
        input_tensor,
        temperature=self.temperature,  # 动态参数
        top_p=self.top_p,
        max_length=self.max_length
    )
```

**3. 系统提示注入**
```python
if self.custom_system_prompt:
    full_prompt = f"{self.custom_system_prompt}\n\n{prompt}"
```

---

## 扩展开发

### 添加自定义命令

```python
# 在 APTAdminMode 类中添加新方法
def _cmd_custom_command(self, args: List[str]) -> str:
    """自定义命令实现"""
    # 你的逻辑
    return "命令执行结果"

# 在 process_command 方法中注册
elif cmd == 'custom':
    return self._cmd_custom_command(args)
```

### 集成新功能

```python
# 扩展 generate_response 方法
def generate_response(self, prompt: str) -> str:
    # 添加自定义预处理
    prompt = self.custom_preprocess(prompt)
    
    # 原有生成逻辑
    response = super().generate_response(prompt)
    
    # 添加自定义后处理
    response = self.custom_postprocess(response)
    
    return response
```

---

## 更新日志

### v1.0.0 (2025-10-25)
- ✨ 初始版本发布
- 🔐 管理员认证系统
- ⚙️ 实时参数调整
- 🐛 高级调试功能
- 📊 性能基准测试
- 💾 会话导出功能

---

## 贡献

欢迎提交问题和改进建议！

---

## 许可证

本项目遵循APT模型的主项目许可证。

---

## 联系方式

如有问题或建议，请通过以下方式联系：
- 提交Issue到项目仓库
- 发送邮件到项目维护者

---

**最后更新**: 2025年10月25日
