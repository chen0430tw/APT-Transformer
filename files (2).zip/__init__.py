#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
APT Model Interactive Module
APT模型交互模块 - 提供聊天和管理员功能

此模块包含:
- chat.py: 标准交互式聊天功能
- admin_mode.py: 高级管理员模式和调试功能
"""

# 导入标准聊天功能
try:
    from .chat import (
        chat_with_model,
        clean_response,
        process_command
    )
    _chat_available = True
except ImportError:
    _chat_available = False
    print("警告: 无法导入标准聊天功能")

# 导入管理员模式
try:
    from .admin_mode import (
        APTAdminMode,
        start_admin_mode
    )
    _admin_mode_available = True
except ImportError:
    _admin_mode_available = False
    print("警告: 无法导入管理员模式")

# 定义模块导出
__all__ = []

if _chat_available:
    __all__.extend([
        'chat_with_model',
        'clean_response',
        'process_command'
    ])

if _admin_mode_available:
    __all__.extend([
        'APTAdminMode',
        'start_admin_mode'
    ])

# 模块信息
__version__ = '1.0.0'
__author__ = 'APT Development Team'
__description__ = 'Interactive module for APT model with chat and admin features'


def get_available_features():
    """
    获取当前可用的功能列表
    
    返回:
        dict: 可用功能的字典
    """
    return {
        'standard_chat': _chat_available,
        'admin_mode': _admin_mode_available
    }


def print_module_info():
    """打印模块信息"""
    print("=" * 60)
    print("APT Interactive Module")
    print("=" * 60)
    print(f"Version: {__version__}")
    print(f"Author: {__author__}")
    print()
    print("Available Features:")
    features = get_available_features()
    print(f"  - Standard Chat: {'✅' if features['standard_chat'] else '❌'}")
    print(f"  - Admin Mode: {'✅' if features['admin_mode'] else '❌'}")
    print("=" * 60)


# 提供便捷的启动函数
def start_chat(**kwargs):
    """
    启动标准聊天模式
    
    参数:
        **kwargs: 传递给 chat_with_model 的参数
    """
    if not _chat_available:
        raise ImportError("标准聊天功能不可用。请确保 chat.py 已正确安装。")
    
    return chat_with_model(**kwargs)


def start_admin(**kwargs):
    """
    启动管理员模式
    
    参数:
        **kwargs: 传递给 start_admin_mode 的参数
    """
    if not _admin_mode_available:
        raise ImportError("管理员模式不可用。请确保 admin_mode.py 已正确安装。")
    
    return start_admin_mode(**kwargs)


# 如果直接运行此模块，显示信息
if __name__ == "__main__":
    print_module_info()
