# APT管理员模式 - 命令快速参考

## 🚀 快速启动

```bash
python start_admin_mode.py --password mypassword
```

---

## 📌 基本命令

| 命令 | 说明 |
|------|------|
| `/login <密码>` | 登录管理员模式 |
| `/help` | 显示帮助 |
| `/exit` | 退出 |
| `/clear` | 清除历史 |

---

## ⚙️ 参数调整

| 命令 | 范围 | 说明 |
|------|------|------|
| `/temp <值>` | 0.0-2.0 | 温度（创造性） |
| `/top_p <值>` | 0.0-1.0 | 采样阈值 |
| `/length <值>` | >0 | 最大长度 |

**快速设置**:
- 保守: `/temp 0.5 /top_p 0.85`
- 平衡: `/temp 0.7 /top_p 0.9`
- 创造: `/temp 0.9 /top_p 0.95`

---

## 🔧 管理员命令（需要登录）

### 安全与调试

| 命令 | 参数 | 说明 |
|------|------|------|
| `/admin` | - | 管理员帮助 |
| `/safety` | on/off | 🔒 安全层 |
| `/debug` | on/off | 🐛 调试模式 |
| `/raw` | on/off | 📝 原始输出 |
| `/probs` | on/off | 📊 词元概率 |

### 系统提示

```bash
/system 你是一个友好的助手
/reset_system
```

### 分析工具

| 命令 | 说明 |
|------|------|
| `/inspect` | 查看模型详情 |
| `/benchmark` | 性能测试 |
| `/stats` | 统计信息 |
| `/visualize` | 可视化 |

### 高级操作

```bash
/export session.json
/override {"temperature": 0.8}
```

---

## 💡 使用技巧

### 1. 测试原始能力
```
/login aptadmin
/safety off
/system 你是一个技术专家
```

### 2. 性能优化
```
/benchmark
/temp 0.7
/length 100
/benchmark
```

### 3. 调试生成
```
/debug on
/probs on
你: 测试问题
```

### 4. 导出研究
```
# 进行对话...
/export research_001.json
```

---

## 🎯 常用场景

### 研究模型行为
```bash
/login aptadmin
/safety off
/debug on
/system 你是研究对象
```

### 风格实验
```bash
/system 你是一个幽默的助手
/temp 0.9
# 开始对话...
```

### 性能基准
```bash
/benchmark
/stats
```

---

## ⚠️ 安全提醒

| 功能 | 风险级别 | 用途 |
|------|----------|------|
| `/safety off` | 🔴 高 | 仅研究 |
| `/debug on` | 🟡 中 | 开发调试 |
| `/system` | 🟡 中 | 行为控制 |
| `/override` | 🔴 高 | 高级调试 |

**规则**:
- ✅ 仅在研究环境使用
- ✅ 保护测试数据
- ❌ 不在生产环境使用
- ❌ 不处理敏感信息

---

## 🔑 密码管理

**默认密码**: `aptadmin`

**修改方式**:

1. 启动参数:
   ```bash
   python start_admin_mode.py --password newpass
   ```

2. 代码修改:
   ```python
   admin_password: str = "newpassword"
   ```

3. 环境变量:
   ```bash
   export APT_ADMIN_PASSWORD="newpass"
   ```

---

## 📊 性能参考

### 温度效果

| 温度 | 效果 | 适用场景 |
|------|------|----------|
| 0.1-0.3 | 确定性强 | 事实性问答 |
| 0.5-0.7 | 平衡 | 一般对话 |
| 0.8-1.0 | 创造性强 | 创意写作 |
| 1.0+ | 随机性高 | 实验探索 |

### Top-p效果

| Top-p | 效果 | 适用场景 |
|-------|------|----------|
| 0.7-0.8 | 保守 | 专业内容 |
| 0.85-0.95 | 平衡 | 一般使用 |
| 0.95-1.0 | 多样 | 创意生成 |

---

## 🆘 故障排查

| 问题 | 解决方案 |
|------|----------|
| 模型加载失败 | `--force-cpu` |
| 命令无效 | 确保 `/` 开头 |
| 权限不足 | `/login` 先登录 |
| 内存不足 | 降低 `max_length` |
| CUDA错误 | `--force-cpu` |

---

## 📞 获取帮助

```bash
# 查看所有命令
/help

# 查看管理员命令
/admin

# 查看当前状态
/stats
```

---

**版本**: v1.0.0  
**最后更新**: 2025-10-25

---

## 🔗 相关文档

- 📖 [完整使用指南](ADMIN_MODE_GUIDE.md)
- 🔧 [API文档](admin_mode.py)
- 🚀 [启动脚本](start_admin_mode.py)
