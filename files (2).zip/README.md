# APT管理员模式完整包

## 📦 文件清单

本包包含APT模型管理员模式的完整实现，用于高级调试和模型研究。

### 核心文件

1. **admin_mode.py** - 管理员模式主文件
   - 完整的 `APTAdminMode` 类实现
   - 所有命令处理逻辑
   - 模型加载和生成功能
   - 约 1000+ 行代码

2. **start_admin_mode.py** - 启动脚本
   - 便捷的命令行启动工具
   - 参数解析和验证
   - 错误处理和帮助信息

3. **__init__.py** - 模块初始化文件
   - 用于将管理员模式集成到APT项目
   - 提供便捷的导入接口

### 文档文件

4. **ADMIN_MODE_GUIDE.md** - 完整使用指南
   - 详细的安装说明
   - 所有命令的完整文档
   - 使用场景和示例
   - 常见问题解答
   - 约 500+ 行文档

5. **QUICK_REFERENCE.md** - 快速参考卡
   - 所有命令速查表
   - 常用场景快速设置
   - 故障排查指南
   - 适合打印或快速查阅

6. **README.md** - 本文件
   - 文件清单和说明
   - 快速开始指南
   - 文件结构说明

---

## 🚀 快速开始

### 1. 放置文件

**方法A: 集成到APT项目**
```
apt_model/
└── interactive/
    ├── __init__.py         ← 替换或合并
    ├── admin_mode.py       ← 新增
    └── chat.py             (保持原有)
```

**方法B: 独立使用**
```
apt_admin/
├── admin_mode.py
├── start_admin_mode.py
├── ADMIN_MODE_GUIDE.md
└── QUICK_REFERENCE.md
```

### 2. 安装依赖

```bash
pip install torch transformers
```

### 3. 启动

```bash
# 基本启动
python start_admin_mode.py

# 带参数启动
python start_admin_mode.py --model-path /path/to/model --password mypassword

# 或直接运行
python admin_mode.py
```

### 4. 登录使用

```
你: /login aptadmin
✅ 管理员身份验证成功!

你: /help
[显示帮助信息]

你: /admin
[显示管理员命令]
```

---

## 📋 核心功能

### 🔓 安全层控制
- 启用/禁用安全过滤
- 用于测试模型原始能力
- 研究安全机制

### 🐛 高级调试
- 词元概率显示
- 生成过程追踪
- 模型内部状态检查

### ⚙️ 实时参数调整
- 温度控制
- Top-p采样
- 最大生成长度

### 🎯 行为定制
- 自定义系统提示
- 原始输出模式
- 参数覆盖

### 📊 性能分析
- 基准测试
- 统计信息
- 可视化工具

### 💾 数据管理
- 会话导出
- 对话历史
- 参数记录

---

## 📖 使用文档

### 快速查阅
- 👉 [命令快速参考](QUICK_REFERENCE.md) - 1页纸速查表
- 📖 [完整使用指南](ADMIN_MODE_GUIDE.md) - 详细文档

### 关键章节

1. **安装与配置** → ADMIN_MODE_GUIDE.md#安装
2. **命令参考** → QUICK_REFERENCE.md
3. **使用场景** → ADMIN_MODE_GUIDE.md#使用场景
4. **常见问题** → ADMIN_MODE_GUIDE.md#常见问题
5. **安全注意事项** → ADMIN_MODE_GUIDE.md#安全注意事项

---

## 🎯 典型使用流程

### 场景1: 模型能力测试

```bash
# 1. 启动
python start_admin_mode.py

# 2. 登录
/login aptadmin

# 3. 配置
/safety off
/debug on
/temp 0.7

# 4. 测试
你: [测试问题]

# 5. 导出
/export test_session.json
```

### 场景2: 对话风格调试

```bash
# 1. 设置系统提示
/system 你是一个专业的技术顾问

# 2. 调整参数
/temp 0.5
/top_p 0.9

# 3. 测试对话
你: 如何优化数据库性能？

# 4. 查看统计
/stats
```

### 场景3: 性能基准测试

```bash
# 1. 运行基准测试
/benchmark

# 2. 调整参数
/temp 0.8
/length 150

# 3. 再次测试
/benchmark

# 4. 比较结果
/stats
```

---

## ⚙️ 命令行参数

### start_admin_mode.py 参数

```bash
--model-path PATH        # 模型路径
--password PASS          # 管理员密码
--temperature FLOAT      # 温度 (0.0-2.0)
--top-p FLOAT           # Top-p (0.0-1.0)
--max-length INT        # 最大长度
--tokenizer-type TYPE   # 分词器类型
--force-cpu             # 强制CPU模式
--verbose               # 详细日志
```

### 示例

```bash
# 完整配置
python start_admin_mode.py \
  --model-path ./my_model \
  --password mysecret123 \
  --temperature 0.8 \
  --top-p 0.95 \
  --max-length 200 \
  --tokenizer-type chinese-char

# 简单配置
python start_admin_mode.py --force-cpu

# 调试模式
python start_admin_mode.py --verbose
```

---

## 🔧 高级配置

### 修改默认密码

**方法1: 环境变量**
```bash
export APT_ADMIN_PASSWORD="newpassword"
python start_admin_mode.py
```

**方法2: 配置文件**
创建 `admin_config.json`:
```json
{
  "admin_password": "newpassword",
  "temperature": 0.7,
  "top_p": 0.9,
  "max_length": 100
}
```

**方法3: 代码修改**
在 `admin_mode.py` 中:
```python
admin_password: str = "newpassword"
```

### 自定义命令

在 `admin_mode.py` 的 `APTAdminMode` 类中添加:

```python
def _cmd_my_command(self, args: List[str]) -> str:
    """自定义命令"""
    # 你的逻辑
    return "结果"

# 在 process_command 中注册
elif cmd == 'mycommand':
    return self._cmd_my_command(args)
```

---

## 📊 文件大小和复杂度

| 文件 | 行数 | 大小 | 复杂度 |
|------|------|------|--------|
| admin_mode.py | ~1000 | ~40KB | 高 |
| start_admin_mode.py | ~100 | ~4KB | 低 |
| __init__.py | ~80 | ~3KB | 低 |
| ADMIN_MODE_GUIDE.md | ~500 | ~25KB | - |
| QUICK_REFERENCE.md | ~200 | ~8KB | - |

**总计**: ~1880 行代码/文档, ~80KB

---

## 🔐 安全建议

### ⚠️ 重要提醒

1. **仅用于研究和开发**
   - ✅ 模型测试和调试
   - ✅ 学术研究
   - ✅ 算法开发
   - ❌ 生产环境
   - ❌ 面向用户服务
   - ❌ 公开演示

2. **密码保护**
   - 默认密码仅供开发
   - 生产环境必须更改
   - 使用强密码
   - 定期更换

3. **数据安全**
   - 妥善保管导出文件
   - 不处理敏感信息
   - 测试数据脱敏

4. **访问控制**
   - 限制文件权限
   - 隔离测试环境
   - 记录操作日志

---

## 🐛 故障排查

### 常见问题

**Q: 模型加载失败**
```bash
# 使用CPU模式
python start_admin_mode.py --force-cpu
```

**Q: 命令不起作用**
```
确保命令以 / 开头
正确: /help
错误: help
```

**Q: 权限不足**
```
先登录: /login <密码>
```

**Q: 内存不足**
```
降低长度: /length 50
使用CPU: --force-cpu
```

**Q: CUDA错误**
```bash
python start_admin_mode.py --force-cpu
```

---

## 📞 获取支持

### 文档资源
- 📖 完整指南: `ADMIN_MODE_GUIDE.md`
- 🔍 快速参考: `QUICK_REFERENCE.md`
- 💻 代码注释: `admin_mode.py`

### 命令帮助
```bash
/help      # 基本帮助
/admin     # 管理员帮助
```

### 问题反馈
- 提交Issue到项目仓库
- 查看已有问题和解决方案

---

## 🔄 更新历史

### v1.0.0 (2025-10-25)
- ✨ 初始发布
- 🔐 管理员认证系统
- ⚙️ 实时参数调整
- 🐛 高级调试功能
- 📊 性能基准测试
- 💾 会话导出
- 📖 完整文档

---

## 📜 许可证

本项目遵循APT模型主项目的许可证。

---

## 🙏 致谢

感谢APT模型开发团队和社区贡献者。

---

## 🚀 下一步

1. ✅ 阅读快速参考: [QUICK_REFERENCE.md](QUICK_REFERENCE.md)
2. ✅ 查看完整指南: [ADMIN_MODE_GUIDE.md](ADMIN_MODE_GUIDE.md)
3. ✅ 启动管理员模式: `python start_admin_mode.py`
4. ✅ 开始探索和调试！

---

**祝您使用愉快！** 🎉

如有问题，请查阅文档或联系项目维护者。
